public class Exercise9{

	public static void main(String[] args){

		int x,y;
		double a;
		String b;

		x = 20;
		y = 3;
		a = 14.6;
		b = "Hello 101";

		System.out.print(x + " and ");
		System.out.println( y + " are both integers in java");
		System.out.println(a + " is considered a float variable");
		System.out.println(b + " is one string variable in java");
	}
}