public class Exercise12 {
  
  public static void main(String[] args){

         //https://www.w3resource.com/java-exercises/basic/java-basic-exercise-46.php
         
         System.out.format("\nCurrent Date time: %tc%n\n", System.currentTimeMillis());
    }
}