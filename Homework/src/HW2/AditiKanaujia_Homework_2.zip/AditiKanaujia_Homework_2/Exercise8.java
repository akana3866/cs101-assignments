public class Exercise8{
	
	public static void main(String[] args){

	int rand = (int)(0 + Math.random() * 11);
	System.out.println("Your random number is: " + rand);
	}
}