/* HelloWorld is the name of the Java class.
Every Java program needs at least one class.*/
public class HelloWorld{
	
	public static void main (String [] args){

		//Display the string
		System.out.println("Hello world!");
	}
}